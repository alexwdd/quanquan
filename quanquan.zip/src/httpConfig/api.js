const apiUrl = 'http://www.worldmedia.top';//线上域名，自己改成自己的 
export default apiUrl